public class DompetDigital {
    private String pin;
    private double saldo;
    protected String idNasabah;
    protected String namaPemilik;
    String statusAkun;

    public DompetDigital(String idNasabah, String namaPemilik, String pinAwal) {
        this.idNasabah = idNasabah;
        this.namaPemilik = namaPemilik;
        this.pin = pinAwal;
        this.saldo = 0.0; 
        this.statusAkun = "AKTIF";

    }
    public String getIdNasabah() { 
        return this.idNasabah; 
    }

    public String getNamaPemilik() { 
        return this.namaPemilik;
    }

    public double getSaldo() { 
        return this.saldo; 
    }

    public void setPin(String pinLama, String pinBaru) {
        if (this.pin.equals(pinLama) && pinBaru.length() == 6) {
            this.pin = pinBaru;
            catatLog("PIN berhasil diubah");
        } else {
            if(!this.pin.equals(pinLama)){
                catatLog("Gagal ubah PIN (PIN salah)");
            }else {
                catatLog("Gagal ubah PIN (PIN harus 6 digit)");
            }
        }
    }
    public void setorTunai(double jumlah) {
        if (this.statusAkun.equals("AKTIF") && jumlah > 0) {
            this.saldo += jumlah;
            catatLog("Setor tunai berhasil " + jumlah);
        } else {
            if (!this.statusAkun.equals("AKTIF")) {
                catatLog("Akun sedang nonaktif");
            }else {
                catatLog("Nominal error");
            }
        }
    }

    public void tarikTunai(double jumlah, String pinInput) {
        if (this.statusAkun.equals("AKTIF") && this.pin.equals(pinInput) && jumlah > 0 && this.saldo >= jumlah) {
            this.saldo -= jumlah;
            catatLog("Tarik tunai berhasil " + jumlah);
        } else {
            if (!this.statusAkun.equals("AKTIF")) {
                catatLog("Akun sedang nonaktif");
            }else if (!this.pin.equals(pinInput)) {
                catatLog("PIN salah");
            }else {
                catatLog("Saldo kurang");
            }
        }
    }

    private void catatLog(String pesan) {
        System.out.println("Pesan: " + pesan); 
    }
}