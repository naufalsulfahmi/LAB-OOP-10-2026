public class Main {
    public static void main(String[] args) {
        DompetDigital dompet1 = new DompetDigital("H082", "Nomas", "123456");

        System.out.println("ID Nasabah   : " + dompet1.getIdNasabah());
        System.out.println("Nama Pemilik : " + dompet1.getNamaPemilik() + "\n");

        dompet1.setPin("111111", "654321");
        dompet1.setPin("123456", "1234");
        dompet1.setPin("123456", "654321");

        dompet1.setorTunai(10000);
        dompet1.setorTunai(-10000);

        dompet1.tarikTunai(2000, "111111");
        dompet1.tarikTunai(100000, "654321");
        dompet1.tarikTunai(2000, "654321");

        System.out.println("Sisa saldo : " + dompet1.getSaldo());
    }
}