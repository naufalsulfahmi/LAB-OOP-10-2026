public class Main {
    public static void main(String[] args) {
        CelenganDigital celengan1 = new CelenganDigital("Nomas", "123456");

        System.out.println("Nama Pemilik : " + celengan1.namaPemilik);
        System.out.println("Tipe Celengan : " + celengan1.tipeCelengan);

        celengan1.ubahPin("111111", "654321");
        celengan1.ubahPin("123456", "654321");

        celengan1.nabung(-100);
        celengan1.nabung(500);

        celengan1.bongKar(200, "123456");
        celengan1.bongKar(200, "654321");
    }
}
