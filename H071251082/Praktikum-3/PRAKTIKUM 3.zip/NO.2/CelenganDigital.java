public class CelenganDigital{
    private int koin;
    private String pin;
    protected String namaPemilik;
    String tipeCelengan;

    public CelenganDigital(String namaPemilik, String pin){
        this.namaPemilik = namaPemilik;
        this.pin = pin;
        this.koin = 0;
        this.tipeCelengan = "Ayam Jago";
    }

    public String getNamaPemilik(){
        return this.namaPemilik;
    }

    public void ubahPin(String pinLama, String pinBaru){
        if (this.pin.equals(pinLama)){
            this.pin = pinBaru;
            log("Berhasil ubah PIN");
        }else {
            log("Gagal ubah PIN");
        }
    }

    public void nabung(int jumlah){
        if (jumlah > 0){
            this.koin += jumlah;
            log("Koin telah ditambahkan sebanyak " + jumlah);
        }else{
            log("Jumlah harus lebih besar dari 0");
        }
    }

    public void bongKar(int jumlah, String inputPin){
        if (this.pin.equals(inputPin) && koin > jumlah){
            koin -= jumlah;
            log("Koin berhasil diambil sebanyak " + jumlah);
        }else if (!this.pin.equals(inputPin)){
            log("Koin gagal diambil karena PIN salah");
        }else {
            log("Jumlah koin tidak mencukupi");
        }
    }

    private void log(String pesan){
        System.out.println("PESAN : " + pesan);
    }
}